import re
from urllib.parse import urlparse
from .rate_limit_helpers import derive_riot_service, derive_riot_method_config
from .exceptions import ApplicationRateLimitExceeded, MethodRateLimitExceeded, ServiceRateLimitExceeded, UnspecifiedRateLimitExceeded
from .settings.config import ND_CUSTOM_MINUTES_LIMIT, ND_CUSTOM_MINUTES_WINDOW, ND_CUSTOM_SECONDS_LIMIT, ND_CUSTOM_SECONDS_WINDOW, ND_PRODUCTION, ND_LOG_LEVEL
from .json_types import RiotOffendingContext
from .utilities import custom_print

DEFAULT_RETRY_AFTER_SECONDS = 61

###### Rate Limier Classes ###########
###### Rate Limier Classes ###########
###### Rate Limier Classes ###########
###### All time units are seconds ####
###### ex. minutes_windows = 600 is ##
###### == 10 minutes #################

class BaseRateLimitingLogic:
    """Base class for rate limiting logic using Redis."""
    def __init__(self, riot_endpoint: str, async_redis_client):
        self.riot_endpoint = riot_endpoint
        self.routing_value = self.get_routing_value(riot_endpoint)
        self.redis = async_redis_client

    @staticmethod
    def key_token(value: str) -> str:
        """Convert a service or method identifier into a readable key token."""
        token = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
        return token or "unknown"

    def get_routing_value(self, riot_endpoint: str):
        """Return the first hostname component used as Riot's routing value.

        This is the subdomain in the generic web-development sense. Riot
        documentation incorrectly calls it a ``region``; the third-party
        developer community often calls it a platform router. ``routing_value``
        describes its role in the rate-limit model.
        """
        parsed_url = urlparse(riot_endpoint)
        hostname = parsed_url.hostname  # Ex. "na1.api.riotgames.com"
        
        if not hostname:
            raise ValueError(f"Invalid URL: No hostname found. Routing value cannot be determined from {riot_endpoint}")

        routing_value = hostname.split(".")[0]  # Extracts "na1" from "na1.api.riotgames.com"
        return routing_value.lower()


class ApplicationRateLimiter(BaseRateLimitingLogic):
    """Rate limiter for app-wide limits per Riot routing value."""
    def __init__(self, riot_endpoint: str, async_redis_client):
        super().__init__(riot_endpoint, async_redis_client)
        if ND_PRODUCTION:
            # Limit / max count for the two types of rate limits
            self.seconds_limit: int = ND_CUSTOM_SECONDS_LIMIT or 500
            self.minutes_limit: int = ND_CUSTOM_MINUTES_LIMIT or 30000
            # Validity windows in seconds for the two types of rate limits
            self.seconds_window: int = ND_CUSTOM_SECONDS_WINDOW or 10
            self.minutes_window: int = ND_CUSTOM_MINUTES_WINDOW or 600
        else:
            # Limit / max count for the two types of rate limits
            self.seconds_limit: int = 20
            self.minutes_limit:int = 100
            # Validity windows in seconds for the two types of rate limits
            self.seconds_window: int = 1
            self.minutes_window: int = 120
        # Redis keys that will identify what application rate limit we are checking
        self.seconds_key: str = self.generate_key("seconds")
        self.minutes_key: str = self.generate_key("minutes")
        self.blocking_key: str = self.generate_blocking_key()

        # Initialize script content but don't load yet
        self.check_and_increment_script_content = self.get_check_and_increment_script()
        self.blocking_script_content = self.get_blocking_script()
        
        # SHA values will be set during initialization
        self.check_and_increment_sha = None
        self.blocking_script_sha = None

    def generate_key(self, window_type):
        """
        Generate application rate limit keys.
        This holds an integer count value that gets incremented by 1 per request. One half of what is_allowed() checks.
        """
        return f"nd:application:count:{self.routing_value}:{window_type}"
    
    def generate_blocking_key(self):
        """
        Generate a blocking key for the application rate limiter.
        If "leakage" occurs (i.e. my internal counts fail to prevent an inbound 429 from Riot
        either becasue our counts are out of sync or Riot issues a 429 for an unknown reason)
        then we use this blocking key with a TTL set to the "Retry-After" header's integer value so we respect the timeout
        for as long as it is valid whether or not our internal counts hit their limit.
        """
        return f"nd:application:block:{self.routing_value}"


    def get_check_and_increment_script(self):
        """Returns the Lua script content for atomic check and increment operations."""
        return """
        -- Keys: [seconds_key, minutes_key, blocking_key]
        -- Args: [seconds_limit, minutes_limit, seconds_window, minutes_window]
        
        local seconds_key = KEYS[1]
        local minutes_key = KEYS[2]
        local blocking_key = KEYS[3]
        
        local seconds_limit = tonumber(ARGV[1])
        local minutes_limit = tonumber(ARGV[2])
        local seconds_window = tonumber(ARGV[3])
        local minutes_window = tonumber(ARGV[4])
        
        -- Check if blocking key exists (external rate limit was hit)
        local is_blocked = redis.call('EXISTS', blocking_key)
        if is_blocked == 1 then
            local block_ttl = redis.call('TTL', blocking_key)
            return {0, block_ttl, 0, 0, "blocking_key"}
        end
        
        -- Get current counts
        local seconds_count = tonumber(redis.call('GET', seconds_key) or "0")
        local minutes_count = tonumber(redis.call('GET', minutes_key) or "0")
        
        -- Check if limits exceeded
        if seconds_count >= seconds_limit then
            local seconds_ttl = redis.call('TTL', seconds_key)
            return {0, seconds_ttl, seconds_count, minutes_count, "seconds"}
        end
        
        if minutes_count >= minutes_limit then
            local minutes_ttl = redis.call('TTL', minutes_key)
            return {0, minutes_ttl, seconds_count, minutes_count, "minutes"}
        end
        
        -- Increment counts and set expiry if needed
        -- Handle seconds key
        local seconds_exists = redis.call('EXISTS', seconds_key)
        redis.call('INCR', seconds_key)
        if seconds_exists == 0 then
            redis.call('EXPIRE', seconds_key, seconds_window)
        end
        
        -- Handle minutes key
        local minutes_exists = redis.call('EXISTS', minutes_key)
        redis.call('INCR', minutes_key)
        if minutes_exists == 0 then
            redis.call('EXPIRE', minutes_key, minutes_window)
        end
        
        -- Return success and new counts
        return {1, 0, seconds_count + 1, minutes_count + 1, "allowed"}
        """
    
    def get_blocking_script(self):
        """Returns the Lua script content for handling blocking keys."""
        return """
        local blocking_key = KEYS[1]
        local retry_after = tonumber(ARGV[1])
        
        -- Check if key exists and get its TTL
        local exists = redis.call('EXISTS', blocking_key)
        local current_ttl = 0
        
        if exists == 1 then
            current_ttl = redis.call('TTL', blocking_key)
        end
        
        -- Only set the key if it doesn't exist OR if new retry_after is longer than remaining TTL
        if exists == 0 or retry_after > current_ttl then
            redis.call('SET', blocking_key, 1, 'EX', retry_after)
        end
        
        return {exists, current_ttl}
        """
    
    async def initialize_scripts(self):
        """Initialize the Lua scripts and store their SHA values."""
        if self.check_and_increment_sha is None:
            self.check_and_increment_sha = await self.redis.script_load(self.check_and_increment_script_content)
        
        if self.blocking_script_sha is None:
            self.blocking_script_sha = await self.redis.script_load(self.blocking_script_content)
    
    async def check_and_increment(self):
        """
        Atomically check if the request is allowed and increment counters if it is.
        Returns True if allowed, raises exception otherwise.
        """
        # Make sure scripts are initialized
        if self.check_and_increment_sha is None:
            await self.initialize_scripts()
        
        # Execute the Lua script using the stored SHA
        result = await self.redis.evalsha(
            self.check_and_increment_sha,
            3,  # number of keys
            self.seconds_key, 
            self.minutes_key, 
            self.blocking_key,
            self.seconds_limit, 
            self.minutes_limit, 
            self.seconds_window, 
            self.minutes_window
        )
        
        is_allowed, retry_after, seconds_count, minutes_count, reason = result
        
        if is_allowed == 0:  # Request not allowed
            raise ApplicationRateLimitExceeded(
                retry_after=retry_after if retry_after >= 1 else 1,
                minutes_key=self.minutes_key,
                seconds_key=self.seconds_key,
                seconds_window=self.seconds_window,
                minutes_window=self.minutes_window,
                routing_value=self.routing_value,
                enforcement_type="internal",
                riot_endpoint=self.riot_endpoint,
                seconds_count=seconds_count,
                seconds_limit=self.seconds_limit,
                minutes_count=minutes_count,
                minutes_limit=self.minutes_limit,
                reason=f"The '{reason}' key count/limit/existence was violated."
            )
        
        return True

    async def write_inbound_application_rate_limit(self, retry_after: int, offending_context: RiotOffendingContext):
        """
        Set the application rate limit blocking key in Redis with a TTL.
        This is only for when we actually experience a 429 response with X-Rate-Limit-Type header
        with a value of "application"
        """
        if not retry_after:
            retry_after = DEFAULT_RETRY_AFTER_SECONDS
            
        # Make sure scripts are initialized
        if self.blocking_script_sha is None:
            await self.initialize_scripts()
        
        # Execute the blocking script using the stored SHA
        result = await self.redis.evalsha(
            self.blocking_script_sha,
            1,  # number of keys
            self.blocking_key,
            retry_after
        )
        
        exists, current_ttl = result
        
        # Use the max of the existing TTL and new retry_after to ensure we respect the longest timeout
        effective_retry_after = max(retry_after, current_ttl) if exists else retry_after
        
        raise ApplicationRateLimitExceeded(
            retry_after=effective_retry_after,
            minutes_key=self.minutes_key,
            seconds_key=self.seconds_key,
            seconds_window=self.seconds_window,
            minutes_window=self.minutes_window,
            enforcement_type="external",
            routing_value=self.routing_value,
            riot_endpoint=self.riot_endpoint,
            offending_context=offending_context,
            seconds_limit=self.seconds_limit,
            minutes_limit=self.minutes_limit,
            reason="Inbound 429 actually experienced. Did not prevent Riot from serving a 429."
        )


class MethodRateLimiter(BaseRateLimitingLogic):
    """
    Rate limiter that respects method (i.e. endpoint) based rate limits per routing value.
    (A routing value is the subdomain in the generic web-development sense,
    what Riot incorrectly calls 'region' in their docs, or what the 3rd Party
    Developer community calls a 'platform router'.)
    """

    def __init__(self, riot_endpoint: str, async_redis_client):
        super().__init__(riot_endpoint, async_redis_client)
        self.service = derive_riot_service(riot_endpoint)
        self.config = derive_riot_method_config(riot_endpoint, self.routing_value, self.service)

        self.method = self.config["method"]
        self.seconds_limit: int | None = self.config["seconds"]["limit"]
        self.seconds_window: int | None = self.config["seconds"]["window"]

        self.minutes_limit: int | None = self.config["minutes"]["limit"]
        self.minutes_window: int | None = self.config["minutes"]["window"]

        # Generate Redis keys.
        self.seconds_key = self.generate_key("seconds") if self.seconds_limit is not None else None
        self.minutes_key = self.generate_key("minutes") if self.minutes_limit is not None else None
        self.blocking_key: str = self.generate_blocking_key()

        # Initialize script content but don't load yet
        self.check_and_increment_script_content = self.get_check_and_increment_script()
        self.blocking_script_content = self.get_blocking_script()
        
        # SHA values will be set during initialization
        self.check_and_increment_sha = None
        self.blocking_script_sha = None


    def generate_key(self, window_type: str) -> str:
        service = self.key_token(self.service)
        method = self.key_token(self.method)
        return f"nd:method:count:{self.routing_value}:{service}:{method}:{window_type}"

    def generate_blocking_key(self):
        """
        Generate a blocking key for the method rate limiter.
        If "leakage" occurs (i.e. my internal counts fail to prevent an inbound 429 from Riot
        either becasue our counts are out of sync or Riot issues a 429 for an unknown reason)
        then we use this blocking key with a TTL set to the "Retry-After" header so we respect the timeout
        for as long as it is valid whether or not our internal counts hit their limit.
        """
        service = self.key_token(self.service)
        method = self.key_token(self.method)
        return f"nd:method:block:{self.routing_value}:{service}:{method}"

    def get_check_and_increment_script(self):
        """Returns the Lua script content for atomic check and increment operations."""
        return """
        -- Keys: [seconds_key, minutes_key, blocking_key]
        -- Args: [seconds_limit, minutes_limit, seconds_window, minutes_window, has_seconds, has_minutes]
        
        local seconds_key = KEYS[1]
        local minutes_key = KEYS[2]
        local blocking_key = KEYS[3]
        
        local seconds_limit = tonumber(ARGV[1])
        local minutes_limit = tonumber(ARGV[2])
        local seconds_window = tonumber(ARGV[3])
        local minutes_window = tonumber(ARGV[4])
        local has_seconds = tonumber(ARGV[5])
        local has_minutes = tonumber(ARGV[6])
        
        -- Check if blocking key exists (external rate limit was hit)
        local block_exists = redis.call('EXISTS', blocking_key)
        if block_exists == 1 then
            local block_ttl = redis.call('TTL', blocking_key)
            return {0, block_ttl, 0, 0, "blocking_key"}
        end
        
        -- Check seconds limit if it exists
        local seconds_count = 0
        local seconds_ttl = 0
        if has_seconds == 1 then
            seconds_count = tonumber(redis.call('GET', seconds_key) or "0")
            if seconds_count >= seconds_limit then
                seconds_ttl = redis.call('TTL', seconds_key)
                return {0, seconds_ttl, seconds_count, 0, "seconds"}
            end
        end
        
        -- Check minutes limit if it exists
        local minutes_count = 0
        local minutes_ttl = 0
        if has_minutes == 1 then
            minutes_count = tonumber(redis.call('GET', minutes_key) or "0")
            if minutes_count >= minutes_limit then
                minutes_ttl = redis.call('TTL', minutes_key)
                return {0, minutes_ttl, seconds_count, minutes_count, "minutes"}
            end
        end
        
        -- Increment counts and set expiry if needed
        -- Handle seconds key if it exists
        if has_seconds == 1 then
            local seconds_exists = redis.call('EXISTS', seconds_key)
            redis.call('INCR', seconds_key)
            if seconds_exists == 0 then
                redis.call('EXPIRE', seconds_key, seconds_window)
            end
            seconds_count = seconds_count + 1
        end
        
        -- Handle minutes key if it exists
        if has_minutes == 1 then
            local minutes_exists = redis.call('EXISTS', minutes_key)
            redis.call('INCR', minutes_key)
            if minutes_exists == 0 then
                redis.call('EXPIRE', minutes_key, minutes_window)
            end
            minutes_count = minutes_count + 1
        end
        
        -- Return success and new counts
        return {1, 0, seconds_count, minutes_count, "allowed"}
        """

    def get_blocking_script(self):
        """Returns the Lua script content for handling blocking keys."""
        return """
        local blocking_key = KEYS[1]
        local retry_after = tonumber(ARGV[1])
        
        -- Check if key exists and get its TTL
        local exists = redis.call('EXISTS', blocking_key)
        local current_ttl = 0
        
        if exists == 1 then
            current_ttl = redis.call('TTL', blocking_key)
        end
        
        -- Only set the key if it doesn't exist OR if new retry_after is longer than remaining TTL
        if exists == 0 or retry_after > current_ttl then
            redis.call('SET', blocking_key, 1, 'EX', retry_after)
        end
        
        return {exists, current_ttl}
        """

    async def initialize_scripts(self):
        """Initialize the Lua scripts and store their SHA values."""
        if self.check_and_increment_sha is None:
            self.check_and_increment_sha = await self.redis.script_load(self.check_and_increment_script_content)
        
        if self.blocking_script_sha is None:
            self.blocking_script_sha = await self.redis.script_load(self.blocking_script_content)

    async def check_and_increment(self):
        """
        Atomically check if the request is allowed and increment counters if it is.
        Returns True if allowed, raises exception otherwise.
        """
        if self.seconds_key is None and self.minutes_key is None:
            raise TypeError("Logical mistake was made. A rate limit must have either a seconds key and/or a minutes key. They cannot both be null.")
        
        # Make sure scripts are initialized
        if self.check_and_increment_sha is None:
            await self.initialize_scripts()
        
        # Convert None values to empty strings for Redis keys
        seconds_key = self.seconds_key or ""
        minutes_key = self.minutes_key or ""
        
        # Prepare arguments
        has_seconds = 1 if self.seconds_key is not None else 0
        has_minutes = 1 if self.minutes_key is not None else 0
        
        # Execute the Lua script atomically
        result = await self.redis.evalsha(
            self.check_and_increment_sha,
            3,  # number of keys
            seconds_key, 
            minutes_key, 
            self.blocking_key,
            self.seconds_limit or 0, 
            self.minutes_limit or 0, 
            self.seconds_window or 0, 
            self.minutes_window or 0,
            has_seconds,
            has_minutes
        )
        
        is_allowed, retry_after, seconds_count, minutes_count, reason = result

        if is_allowed == 0:  # Request not allowed
            raise MethodRateLimitExceeded(
                retry_after=retry_after if retry_after >= 1 else 1,
                method=self.method,
                service=self.service,
                minutes_key=self.minutes_key,
                seconds_key=self.seconds_key,
                seconds_window=self.seconds_window,
                minutes_window=self.minutes_window,
                enforcement_type="internal",
                routing_value=self.routing_value,
                riot_endpoint=self.riot_endpoint,
                seconds_count=seconds_count,
                seconds_limit=self.seconds_limit,
                minutes_count=minutes_count,
                minutes_limit=self.minutes_limit,
                reason=f"The '{reason}' key count/limit/existence was violated."
            )
        
        return True
    
    async def write_inbound_method_rate_limit(self, retry_after: int, offending_context: RiotOffendingContext):
        """
        Set the method rate limit blocking key in Redis with a TTL. This is only for when we actually experience a
        429 response with X-Rate-Limit-Type header with a value of "method"
        """
        if not retry_after:
            retry_after = DEFAULT_RETRY_AFTER_SECONDS
        
        # Make sure scripts are initialized
        if self.blocking_script_sha is None:
            await self.initialize_scripts()
        
        # Execute the blocking script using the stored SHA
        result = await self.redis.evalsha(
            self.blocking_script_sha,
            1,  # number of keys
            self.blocking_key,
            retry_after
        )
        
        exists, current_ttl = result
        
        # Use the max of the existing TTL and new retry_after to ensure we respect the longest timeout
        effective_retry_after = max(retry_after, current_ttl) if exists else retry_after
        
        raise MethodRateLimitExceeded(
            retry_after=effective_retry_after,
            minutes_key=self.minutes_key,
            seconds_key=self.seconds_key,
            seconds_window=self.seconds_window,
            minutes_window=self.minutes_window,
            enforcement_type="external",
            method=self.method,
            service=self.service,
            routing_value=self.routing_value,
            riot_endpoint=self.riot_endpoint,
            offending_context=offending_context,
            seconds_limit=self.seconds_limit,
            minutes_limit=self.minutes_limit,
            reason="Inbound 429 actually experienced. Did not prevent Riot from serving a 429."
        )

class ServiceRateLimiter(BaseRateLimitingLogic):
    """
    Rate limiter for service-wide rate limits per routing value.
    Riot commonly omits the 'Retry-After' header for service rate limits, so the
    class retains a short fallback while accepting a usable value when one is present.
    """

    SERVICE_BLOCK_DURATION = DEFAULT_RETRY_AFTER_SECONDS
    def __init__(self, riot_endpoint: str, async_redis_client):
        super().__init__(riot_endpoint, async_redis_client)
        self.service = derive_riot_service(riot_endpoint)
        self.service_key = self.generate_key()

    def generate_key(self) -> str:
        """Generate a unique key for the service rate limit."""
        service = self.key_token(self.service)
        return f"nd:service:block:{self.routing_value}:{service}"

    async def is_allowed(self):
        """Check if the request is allowed under the service rate limit."""
        if await self.redis.exists(self.service_key):
            raise ServiceRateLimitExceeded(
                retry_after=self.__class__.SERVICE_BLOCK_DURATION,
                service=self.service,
                enforcement_type="internal",
                routing_value=self.routing_value,
                riot_endpoint=self.riot_endpoint
                )
        return True
    
    async def write_inbound_service_rate_limit(
        self,
        offending_context: RiotOffendingContext,
        retry_after: int | None = None,
    ):
        """Set the service block, using a valid Riot value when one is present."""
        effective_retry_after = (
            retry_after if retry_after is not None and retry_after >= 1
            else self.__class__.SERVICE_BLOCK_DURATION
        )
        await self.redis.set(self.service_key, 1, ex=effective_retry_after, nx=True)

        raise ServiceRateLimitExceeded(
            retry_after=effective_retry_after,
            service=self.service,
            routing_value=self.routing_value,
            riot_endpoint=self.riot_endpoint,
            offending_context=offending_context,
            enforcement_type="external"
        )
    
class UnspecifiedRiotRateLimiter(BaseRateLimitingLogic):
    """Fallback limiter for unexpected Riot rate limits.

    Most services retain the conservative shared routing-value fallback. Spectator's
    active-game method has its own fallback because its server-enforced throttles
    are observed independently of the normal application, method, and service limits.
    """
    def __init__(self, riot_endpoint, async_redis_client):
        super().__init__(riot_endpoint, async_redis_client)
        self.service = derive_riot_service(riot_endpoint)
        self.config = derive_riot_method_config(riot_endpoint, self.routing_value, self.service)
        self.method = self.config["method"]
        self.blocking_key = self.generate_blocking_key()

    def generate_blocking_key(self) -> str:
        """Return the fallback block key, isolating Spectator from other APIs."""
        if self.service == "SPECTATOR-V5":
            service = self.key_token(self.service)
            method = self.key_token(self.method)
            return f"nd:known-unpredictable:block:{self.routing_value}:{service}:{method}"

        return f"nd:unspecified:block:{self.routing_value}:shared"

    async def is_allowed(self):
        """Check if the request is allowed under the experienced but unspecified rate limit."""
        # Use a pipeline to execute both commands in a single transaction
        async with self.redis.pipeline() as pipe:
            # Queue both commands
            await pipe.exists(self.blocking_key)
            await pipe.ttl(self.blocking_key)
            # Execute the pipeline and get results
            exists, remaining_ttl = await pipe.execute()
        
        if exists:
            # Ensure non-negative TTL value
            remaining_ttl = max(1, remaining_ttl)

            if ND_LOG_LEVEL >= 2:
                custom_print({
                    "event": "riot_rate_limit_blocked_before_request",
                    "rate_limit_type": "unspecified",
                    "enforcement_type": "internal",
                    "service": self.service,
                    "method": self.method,
                    "routing_value": self.routing_value,
                    "riot_endpoint": self.riot_endpoint,
                    "blocking_key": self.blocking_key,
                    "remaining_ttl_seconds": remaining_ttl,
                }, color="yellow")
            
            raise UnspecifiedRateLimitExceeded(
                retry_after=remaining_ttl,
                service=self.service,
                method=self.method,
                enforcement_type="internal",
                routing_value=self.routing_value,
                riot_endpoint=self.riot_endpoint,
                offending_context=None
            )
        return True
    
    async def write_inbound_unspecified_rate_limit(self, retry_after: int, offending_context: RiotOffendingContext):
        """
        Set the unspecified rate limit blocking key in Redis with a TTL. This is only for when we actually expereince a
        429 response with a missing X-Rate-Limit-Type header or unknown value. 
        """
        if not retry_after:
            retry_after = DEFAULT_RETRY_AFTER_SECONDS
        # Create the key with the configured fallback TTL if it doesn't already exist (NX)
        await self.redis.set(self.blocking_key, 1, ex=retry_after, nx=True)
        raise UnspecifiedRateLimitExceeded(
            retry_after=retry_after,
            enforcement_type="external",
            routing_value=self.routing_value,
            riot_endpoint=self.riot_endpoint,
            offending_context=offending_context,
            service=self.service,
            method=self.method
        )
